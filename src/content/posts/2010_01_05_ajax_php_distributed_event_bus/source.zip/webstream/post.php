<?php

	/*
	Copyright (c) Georg Hackenberg, 2010

	This file is part of WebStream.

	WebStream is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	WebStream is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with WebStream.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
	*/

	header("Cache-Control: no-cache, must-revalidate");
    header("Pragma: no-cache");
	
	$lock = fopen("access.lock", "r");
	
	while (!flock($lock, LOCK_EX)) {
	
	}
	
	$timestamp = split(" ", microtime());
	
	$channel = simplexml_load_file("channel.xml");
	$item = $channel->addChild("item");
	$item['timestamp'] = $timestamp[1];
	$item['microseconds'] = $timestamp[0];
	$item['client'] = $_POST['client'];
	$item['type'] = $_POST['type'];
	$item->content = $_POST['content'];
	
	$dom = dom_import_simplexml($channel);
	
	foreach ($channel->item as $item) {
		if ((int) $item['timestamp'] < (int) $timestamp[1] - 10) { // remove items older than 10 seconds
			$dom->removeChild($dom->firstChild);
		}
		else {
			break;
		}
	}
	
	$dom->ownerDocument->save("channel.xml");
	
	while (!flock($lock, LOCK_UN)) {
	
	}

?>