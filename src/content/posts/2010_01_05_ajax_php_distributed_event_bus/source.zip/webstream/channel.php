<?php

	/*
	Copyright (c) Georg Hackenberg, 2010

	This file is part of WebStream.

	WebStream is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	WebStream is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with WebStream.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
	*/

	header("Cache-Control: no-cache, must-revalidate");
    header("Pragma: no-cache");
	header("Content-Type: text/xml");
	
	$lock = fopen("access.lock", "r");
	
	ob_end_flush();
	
	$timestamp = (int) $_GET['timestamp'];
	$microseconds = (float) $_GET['microseconds'];
	
	$last_timestamp;
	$last_microseconds;
	
	print("<channel>");
	flush();
	
	$start = time();
	while (time() - $start < 25) {
	
		while (!flock($lock, LOCK_SH)) {
		
		}
		$channel = simplexml_load_file("channel.xml");
		while (!flock($lock, LOCK_UN)) {
		
		}
		
		foreach ($channel->item as $item) {
			if ((int) $item['timestamp'] > $timestamp || ((int) $item['timestamp'] == $timestamp && (float) $item['microseconds'] > $microseconds)) {
				print($item->asXML());
				flush();
				$last_timestamp = (int) $item['timestamp'];
				$last_microseconds = (float) $item['microseconds'];
			}
		}
		
		if ($last_timestamp && $last_microseconds) {
			$timestamp = $last_timestamp;
			$microseconds = $last_microseconds;
		}
		
		usleep(20000);
	}
	
	print("</channel>");
	flush();

?>