<?php

	/*
	Copyright (c) Georg Hackenberg, 2010

	This file is part of WebStream.

	WebStream is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	WebStream is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with WebStream.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
	*/

	$timestamp = split(" ", microtime());
	
?>
<html>
	<head>
		<title>AJAX Channel Client</title>
		<style type="text/css">
			body {
				font-family: sans-serif;
				font-size: 10pt;
				line-height: 150%;
			}
			span {
				font-weight: bold;
			}
			.edit {
				color: red;
			}
			ul {
				list-style: none;
				padding: 0px;
				margin: 0px;
			}
		</style>
		<script type="text/javascript">
			// VARIABLES
			var client = Math.round(Math.random() * 1000000);
			var timestamp = "<?php print($timestamp[1]); ?>";
			var microseconds = "<?php print($timestamp[0]); ?>";
			var handlers = new Object();
			var channel;
			var timeout;
			var position;
			var username = prompt("Please choose your username:", "anonymous");
			var color = prompt("Please choose your color:", "black");
			var expression = /<item timestamp="([0-9]+)" microseconds="([0-9\.]+)" client="([0-9]+)" type="([a-z]+)">(<content>(.*?)<\/content>|<content\/>)<\/item>/;
			
			// FUNCTIONS
			function Connect() {
				channel = new XMLHttpRequest();
				channel.onreadystatechange = ChannelChange;
				channel.open("GET", "channel.php?timestamp=" + timestamp + "&microseconds=" + microseconds);
				channel.send(null);
				
				position = 0;
				
				Update();
			}
			function ChannelChange(event) {
				var channel = event.target;
				
				if (channel.readyState == 4) {
					Update();
					Connect();
				}
			}
			function Update() {
				var relevant = channel.responseText.substring(position);
				var next;
				var end;
				var item;
				var parts;
				var content;
				
				while ((next = relevant.indexOf("<item")) != -1) {
					if ((end = relevant.indexOf("</item>")) != -1) {
						item = relevant.substring(next, end + 7);
						relevant = relevant.substring(end + 7);
						position += end + 7;
						
						parts = expression.exec(item);
						
						timestamp = parts[1];
						microseconds = parts[2];
						content = parts[6] ? parts[6] : "";
						Notify(timestamp, microseconds, parts[3], parts[4], content);
					}
					else { // the entire tag is not transmitted yet
						position = next;
						break;
					}
				}
			
				if (timeout) {
					window.clearTimeout(timeout);
				}
				timeout = window.setTimeout(Update, 20);
			}
			function Post(type, content) {
				var body = "client=" + client + "&type=" + encodeURIComponent(type) + "&content=" + encodeURIComponent(content);
				var post = new XMLHttpRequest();
				post.onreadystatechange = PostChange;
				post.open("POST", "post.php");
				post.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				post.setRequestHeader("Content-length", body.length);
				post.setRequestHeader("Connection", "close");
				post.send(body);
			}
			function PostChange(event) {
				var post = event.target;
			}
			function Notify(timestamp, microseconds, client, type, content) {
				if (handlers[type]) {
					for (var i = 0; i < handlers[type].length; i++) {
						var handler = handlers[type][i];
						handler(timestamp, microseconds, client, type, content);
					}
				}
			}
			function RegisterEventHandler(type, handler) {
					if (!handlers[type]) {
						handlers[type] = new Array();
					}
					
					handlers[type].push(handler);
			}
			
			// CUSTOM EVENT HANDLERS
			var usernames = new Object();
			var colors = new Object();
			function Submit(timestamp, microseconds, client, type, content) {
				var li = document.getElementById(client);
				
				if (li) {
					li.innerHTML = "<span class=\"submit\" style=\"color: " + colors["client_" + client] + ";\">" + usernames["client_" + client] + " sayed:</span> " + content;
					li.id = "";
				}
			}
			function Edit(timestamp, microseconds, client, type, content) {
				var ul = document.getElementById("chat");
				var li = document.getElementById(client);
				if (!li) {
					li = document.createElement("li");
					li.id = client;
					if (ul.childNodes.length == 0) {
						ul.appendChild(li);
					}
					else {
						ul.insertBefore(li, ul.firstChild);
					}
				}
				if (!content) {
					ul.removeChild(li);
				}
				else {
					li.innerHTML = "<span class=\"edit\">" + usernames["client_" + client] + " says:</span> " + content;
				}
			}
			function Alert(timestamp, microseconds, client, type, content) {
				alert(content);
			}
			function Login(timestamp, microseconds, client, type, content) {
				Post("username", username);
				Post("color", color);
				alert("A new user has logged in!");
			}
			function Username(timestamp, microseconds, client, type, content) {
				usernames["client_" + client] = content;
			}
			function Color(timestamp, microseconds, client, type, content) {
				colors["client_" + client] = content;
			}
			RegisterEventHandler("login", Login);
			
			RegisterEventHandler("color", Color);
			RegisterEventHandler("username", Username);
			
			RegisterEventHandler("submit", Submit);
			RegisterEventHandler("edit", Edit);
			RegisterEventHandler("click", Alert);
		</script>
	</head>
	<body onload="Connect(); Post('login', '');">
		<button onclick="Post('click', 'Somebody want\'s to be heard!');">I am online!!</button>
		<form onsubmit="Post('submit', this.content.value); this.content.value = ''; return false;" style="display: inline;">
			<input type="text" name="content" onkeypress="if (event.keyCode != 13) { var input = this; window.setTimeout(function() { Post('edit', input.value); }, 0); }"/>
		</form>
		<ul id="chat"></ul>
	</body>
</html>