<?xml version="1.0" encoding="UTF-8"?>
<!--
	Copyright (c) Georg Hackenberg, 2010

	This file is part of XMLOffice.

	XMLOffice is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	XMLOffice is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with XMLOffice.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format">

	<!-- we are producing XML-FO output -->
	<xsl:output method="xml" indent="yes"/>
	
	<!-- define the recipient parameter which has to be provided by each concrete letter type -->
	<xsl:param name="recipient"/>
	
	<!-- the main template which is called initially -->
	<xsl:template match="/">
		<fo:root>
		
			<!-- page setup -->
			<fo:layout-master-set>
				<fo:simple-page-master master-name="A4-portrait" page-height="29.7cm" page-width="21.0cm" margin="2cm">
					<fo:region-body margin-top="1.5cm" margin-bottom="7.5cm"/>
					<fo:region-before extent="12pt"/>
					<fo:region-after extent="63pt"/>
				</fo:simple-page-master>
			</fo:layout-master-set>
			
			<!-- content definition -->
			<fo:page-sequence master-reference="A4-portrait">
			
				<!-- header -->
				<fo:static-content flow-name="xsl-region-before">
					<fo:block text-align="end" font-size="9pt" border-after-style="solid" border-after-color="black" border-after-width="1pt">
						Hans Muster &#187; Professionelle IT Beratung und Entwicklung
					</fo:block>
				</fo:static-content>
			
				<!-- footer -->	
				<fo:static-content flow-name="xsl-region-after">
					<fo:block-container line-height="1.4" font-size="8pt" border-before-style="solid" border-before-color="black" border-before-width="1pt">
						<!-- contact information -->
						<fo:block-container>
							<fo:block font-weight="bold" space-after="3pt" margin-top="3pt">Kontaktperson</fo:block>
							<fo:block>Name: Hans Muster</fo:block>
							<fo:block>Mobil: +49 (xxx) yyy yyy yy yy</fo:block>
							<fo:block>E-Mail: kontakt@hans-muster.de</fo:block>
							<fo:block>Steuernummer: zzzzzzzzzzz</fo:block>
						</fo:block-container>
						<!-- bank information -->
						<fo:block-container position="absolute" left="8.5cm" top="0cm" text-align="end">
							<fo:block font-weight="bold" space-after="3pt" margin-top="3pt">Bankverbindung</fo:block>
							<fo:block>Kontoinhaber: Hans Muster</fo:block>
							<fo:block>Kontonummer: xxx xxx xx</fo:block>
							<fo:block>Bankleitzahl: yyy yyy yy</fo:block>
							<fo:block>Bank: Meine Bank</fo:block>
						</fo:block-container>
					</fo:block-container>
				</fo:static-content>
				
				<!-- body -->
				<fo:flow flow-name="xsl-region-body">				
					<fo:block-container line-height="1.4" font-size="10pt">
						<fo:block-container margin-top="0.8cm" margin-bottom="2.1cm">
							<!-- sender -->
							<xsl:call-template name="sender"/>
							<!-- recipient -->
							<xsl:call-template name="recipient"/>
						</fo:block-container>
						<!-- dynamic content (e.g. bill-specific stuff) -->
						<xsl:apply-templates/>
						<!-- end -->
						<fo:block space-before="15pt" space-after="15pt">Mit freundlichen Grüßen,</fo:block>
						<fo:block>Hans Muster</fo:block>
					</fo:block-container>
				</fo:flow>
				
			</fo:page-sequence>
			
		</fo:root>
	</xsl:template>
	
	<!-- separate template for printing the sender (static content) -->
	<xsl:template name="sender">
		<fo:block-container position="absolute" top="0cm" left="11.4cm" color="#404040">
			<fo:block font-size="7pt" font-weight="bold" padding-after="7pt">Kontakt:</fo:block>
			<!-- physical address -->
			<fo:block-container font-size="10pt">
				<fo:block>Hans Muster</fo:block>
				<fo:block>Musterstrasse XX</fo:block>
				<fo:block>YYYYY Musterstadt</fo:block>
			</fo:block-container>
			<!-- virtual addresses -->
			<fo:block-container font-size="8pt">
				<fo:block space-before="3pt">Mobil: +49 (xxx) yyy yyy yy</fo:block>
				<fo:block padding-before="3pt">kontakt@hans-muster.de</fo:block>
				<fo:block>http://www.hans-muster.de</fo:block>
			</fo:block-container>
		</fo:block-container>
	</xsl:template>
	
	<!-- separate template for printing the recipient (dynamic content) -->
	<xsl:template name="recipient">
		<!-- print the sender again with tiny font -->
		<fo:block font-size="7pt" text-decoration="underline" padding-after="7pt">Hans Muster, Musterstrasse XX, YYYYY Musterstadt</fo:block>
		<!-- company information -->
		<fo:block font-weight="bold"><xsl:value-of select="$recipient/company"/></fo:block>
		<fo:block font-style="italic" padding-before="3pt" padding-after="3pt"><xsl:value-of select="$recipient/department"/></fo:block>
		<!-- personal contact information -->
		<fo:block>
			<xsl:choose>
				<xsl:when test="$recipient/person/@sex = 'female'">Frau </xsl:when>
				<xsl:when test="$recipient/person/@sex = 'male'">Herr </xsl:when>
			</xsl:choose>
			<xsl:if test="$recipient/person/title">
				<xsl:value-of select="$recipient/person/title"/> 
				<xsl:text> </xsl:text>
			</xsl:if>
			<xsl:value-of select="$recipient/person/first-name"/>
			<xsl:text> </xsl:text>
			<xsl:value-of select="$recipient/person/last-name"/>
		</fo:block>
		<!-- address information -->
		<xsl:choose>
			<xsl:when test="$recipient/address/mailbox">			
				<fo:block>Postfach <xsl:value-of select="$recipient/address/mailbox"/></fo:block>
			</xsl:when>
			<xsl:when test="$recipient/address/street and $recipient/address/building-number">
				<fo:block>
					<xsl:value-of select="$recipient/address/street"/>
					<xsl:text> </xsl:text>
					<xsl:value-of select="$recipient/address/building-number"/>
					<xsl:if test="$recipient/address/appartment-number">
						<xsl:text>, Appartment</xsl:text>
						<xsl:value-of select="$recipient/address/appartment-number"/>
					</xsl:if>
				</fo:block>
			</xsl:when>
		</xsl:choose>
		<!-- country information -->
		<fo:block>
			<xsl:value-of select="$recipient/address/city/@country-sign"/>
			<xsl:text>-</xsl:text>
			<xsl:value-of select="$recipient/address/city/@postal-code"/>
			<xsl:text> </xsl:text>
			<xsl:value-of select="$recipient/address/city"/>
		</fo:block>
	</xsl:template>
	
</xsl:stylesheet>
