<?xml version="1.0" encoding="UTF-8"?>
<!--
	Copyright (c) Georg Hackenberg, 2010

	This file is part of XMLOffice.

	XMLOffice is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	XMLOffice is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with XMLOffice.  If not, see <http://www.gnu.org/licenses/>.
	
	Questions: ghackenberg@gmail.com
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format">

	<!-- include the letter template which provides the main layout -->
	<xsl:import href="Letter.xsl"/>
	
	<!-- select the recipient structure for the letter template -->
	<xsl:param name="recipient" select="/bill/recipient"/>
	
	<!-- define the EURO number format for use with costs -->
	<xsl:decimal-format name="euro" decimal-separator="," grouping-separator="."/>
	
	<!-- print bill-specific content into the body of the letter -->
	<xsl:template match="/bill">
		<!-- print bill meta data -->
		<fo:block-container space-after="30pt">
			<fo:block-container position="absolute" left="11.4cm" top="0cm" font-size="8pt">
				<fo:block>Rechnungsnummer: <xsl:value-of select="about/number"/></fo:block>
				<fo:block>Rechnungsdatum: <xsl:value-of select="about/date"/></fo:block>
				<fo:block>Leistungszeitraum: <xsl:value-of select="about/service-period/start-date"/> - <xsl:value-of select="about/service-period/end-date"/></fo:block>
			</fo:block-container>
			<fo:block line-height="18pt" font-size="18pt" font-weight="bold" space-before="15.6pt">Rechnung</fo:block>
		</fo:block-container>
		<!-- print personalized greeting -->
		<fo:block space-after="15pt">
			<xsl:choose>
				<xsl:when test="recipient/person/@sex = 'female'">Sehr geehrte Frau </xsl:when>
				<xsl:when test="recipient/person/@sex = 'male'">Sehr geehrter Herr </xsl:when>
			</xsl:choose>
			<xsl:if test="recipient/person/title">
				<xsl:value-of select="recipient/person/title"/> 
				<xsl:text> </xsl:text>
			</xsl:if>
			<xsl:value-of select="recipient/person/first-name"/>
			<xsl:text> </xsl:text>
			<xsl:value-of select="recipient/person/last-name"/>,
		</fo:block>
		<!-- print introductory paragraph -->
		<fo:block text-align="justify">
			Hiermit stellen wir folgende Leistungen und/oder Produkte bei Ihnen in Rechnung.
			Bitte beachten Sie, dass <fo:inline font-weight="bold">keine</fo:inline> Umsatzsteuer berechnet wird.
		</fo:block>
		<!-- print the table of items -->
		<fo:table table-layout="fixed" width="100%" space-before="9pt" space-after="9pt">
			<!-- format the column widths -->
			<fo:table-column column-width="proportional-column-width(1)"/>
			<fo:table-column column-width="proportional-column-width(7)"/>
			<fo:table-column column-width="proportional-column-width(2)"/>
			<fo:table-column column-width="proportional-column-width(3)"/>
			<fo:table-column column-width="proportional-column-width(2)"/>
			<!-- define the table header row/cells -->
			<fo:table-header>
				<fo:table-row border-after-style="solid" border-after-color="black" border-after-width="1pt">
					<fo:table-cell padding="3pt">
						<fo:block text-align="center" font-weight="bold">#</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="3pt">
						<fo:block font-weight="bold">Bezeichnung</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="3pt">
						<fo:block text-align="end" font-weight="bold">Anzahl</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="3pt">
						<fo:block text-align="end" font-weight="bold">Preis p. Stk. (in €)</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="3pt">
						<fo:block text-align="end" font-weight="bold">Preis (in €)</fo:block>
					</fo:table-cell>
				</fo:table-row>
			</fo:table-header>
			<!-- define the table contents (individual items of the bill) -->
			<fo:table-body>
				<!-- process each item of the bill -->
				<xsl:for-each select="entries/entry">
					<!-- alternate the color for each row -->
					<xsl:variable name="color">
						<xsl:choose>
							<xsl:when test="position() mod 2">#e0e0e0</xsl:when>
							<xsl:otherwise>white</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>
					<!-- define the row with the alternating color in the background -->
					<fo:table-row background-color="{$color}">
						<fo:table-cell padding="5pt">
							<fo:block text-align="center"><xsl:value-of select="position()"/></fo:block>
						</fo:table-cell>
						<fo:table-cell padding="5pt">
							<fo:block><xsl:value-of select="identification"/></fo:block>
						</fo:table-cell>
						<fo:table-cell padding="5pt">
							<fo:block text-align="end"><xsl:value-of select="quantity"/>x</fo:block>
						</fo:table-cell>
						<fo:table-cell padding="5pt">
							<fo:block text-align="end"><xsl:value-of select="format-number(number(cost), '##.###,00', 'euro')"/></fo:block>
						</fo:table-cell>
						<fo:table-cell padding="5pt">
							<fo:block text-align="end"><xsl:value-of select="format-number(number(quantity*cost), '##.###,00', 'euro')"/></fo:block>
						</fo:table-cell>
					</fo:table-row>
				</xsl:for-each>
				<!-- print the total sum -->
				<fo:table-row border-before-style="solid" border-before-color="black" border-before-width="2pt">
					<fo:table-cell padding="5pt">
						<fo:block></fo:block>
					</fo:table-cell>
					<fo:table-cell padding="5pt">
						<fo:block font-weight="bold">Gesamtsumme</fo:block>
					</fo:table-cell>
					<fo:table-cell padding="5pt">
						<fo:block text-align="end"></fo:block>
					</fo:table-cell>
					<fo:table-cell padding="5pt">
						<fo:block text-align="end"></fo:block>
					</fo:table-cell>
					<fo:table-cell padding="5pt">
						<!-- call the template for calculating the sum -->
						<fo:block font-weight="bold" text-align="end"><xsl:call-template name="sum"/></fo:block>
					</fo:table-cell>
				</fo:table-row>
			</fo:table-body>
		</fo:table>
		<!-- wrap up the letter -->
		<fo:block text-align="justify">
			Bitte überweisen Sie den errechneten Betrag innerhalb der nächsten zwei Wochen auf das unten angegebene Konto.
			Wir bedanken uns für die Zusammenarbeit und hoffen, Sie sind mit den erbrachten Leistungen und installierten Produkten zufrieden.
		</fo:block>
	</xsl:template>
	
	<!-- calculate the sum of the costs of the individual items -->
	<xsl:template name="sum">
		<xsl:param name="partial">0</xsl:param>
		<xsl:param name="item" select="entries/entry[position() = 1]"/>
		<!-- add the costs of the current item -->
		<xsl:variable name="updated" select="$partial+number($item/quantity)*number($item/cost)"/>
		<!-- check if all items have been processed -->
		<xsl:choose>
			<xsl:when test="$item/following-sibling::entry">
				<!-- execute recursive call -->
				<xsl:call-template name="sum">
					<xsl:with-param name="partial" select="$updated"/>
					<xsl:with-param name="item" select="$item/following-sibling::entry"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<!-- return the final value -->
				<xsl:value-of select="format-number($updated, '##.###,00', 'euro')"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
</xsl:stylesheet>

